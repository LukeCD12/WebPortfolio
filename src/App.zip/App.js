import React, { Component, Fragment } from 'react';
import logo from './logo.svg';
import './App.css';

import Header from './Header'

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Fragment>
          <Header />
        </Fragment>
   
        <div className="main-font-cover clipped-box">    
			<div className="font-text content">Welcome</div>
        </div>
      </header>
    </div>
  );
}

export default App;